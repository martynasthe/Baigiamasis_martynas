<section class="content">   <!-- center -->                 
    <div class="centras-kontaktas">   
        <div class="kontaktas" id="slide-1"> 
            <h3>Error 404</h3>
        </div> 
    </div>
</section> 
          