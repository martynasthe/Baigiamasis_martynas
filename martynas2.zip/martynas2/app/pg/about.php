<div class="content">   <!-- center -->                 
    <div class="centras about-top">   
        <section class="centras2 about">
            <img src="app/images/a1.jpg"> 
            <div class="link2 text">
                    <h2>About Me</h2>
                    <p>Martynas is a Lithuanian based photographer who specialises in analogue photography. His work is often abstract and incorporates elements of surrealism, geometry, high contrast and the realities and diversities of human life.</p>     
            </div>         
        </section>
    </div>              <!-- end center -->
</div> 