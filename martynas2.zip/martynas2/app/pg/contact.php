<?php
    require __DIR__ . '/../src/app.php';
?>     
<section class="content">   <!-- center -->                 
    <div class="centras-kontaktas">   
        <div class="kontaktas" id="slide-1"> 
            <h3>Contact Me</h3>
        </div> 
        <div class="kontaktas1">
            <div class="box">
                <div>
                    P
                </div>
                <div>
                    <a href="tel:+37069963021">+37069900001</a>
                </div>
            </div>
            <div class="box">
                <div>
                    E
                </div>
                <div>
                    <a href="mailto:info@martynas.space">info@martynas.space</a>
                </div>   
            </div>
            <div class="box">
                <div>
                    S
                </div>
                <div>
                    <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                </div>        
            </div>
        </div>
        <div class="kontaktas2">
            <div></div>
        </div>
        <div class="section-content">
            <form class="contact-form" action="index.php?page=contact" method="post" >
                <div class="input-row">
                    <input type="text" name="name" placeholder="Your Name*" required >
                    <input type="email" name="email" placeholder="Your Email*" required>
                </div>
                <textarea name="message" rows="8" placeholder="Your Message*" required></textarea>
                <button class="btn btn-form" type="submit" name="submit">send message</button>
            </form>
        </div>
    </div>            <!-- end center -->
</section>