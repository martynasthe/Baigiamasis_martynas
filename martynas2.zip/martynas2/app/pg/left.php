<div class="nav-left">    <!-- navigation left -->
    <div class="main-nav">
        <h3  onclick="openNav()">menu</h3>
            <i class="fas fa-bars" onclick="openNav()"></i>
    </div>   
</div>    <!-- end navigation -->
            