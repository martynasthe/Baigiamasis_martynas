
<div class="content">   <!-- center -->                 
    <div class="centras cmob-top">   
        <section class="centras1 ecmob">
               <div class="text">
                     <h2>.erosion</h2>
                     <p>is a collaborative multiseasonal collection created by A. Zukaite and J. Taroza.</p>
                </div>     
        </section>
        <section class="centras1 cflex cmob ecph " > 
                <div class="photo pleft">
                     <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main15.jpg" alt="photo "><img src="app/images/main15sm.jpg"></a>
                </div>
                <div class="photo pcent">
                    <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main14.jpg"><img src="app/images/main14sm.jpg"></a>
                </div>
                <div class="photo pright">
                    <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main16.jpg"><img src="app/images/main16sm.jpg"></a>   
                </div>
        </section>
        <section class="centras1 cflex cmob ecph" > 
                <div class="photo pleft">
                     <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main17.jpg" alt="photo "><img src="app/images/main17sm.jpg"></a>
                </div>
                <div class="photo pcent">
                    <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main18.jpg"><img src="app/images/main18sm.jpg"></a>
                </div>
                <div class="photo pright">
                    <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main19.jpg"><img src="app/images/main19sm.jpg"></a>   
                </div>
        </section>
    </div>               <!-- end center -->
</div> 