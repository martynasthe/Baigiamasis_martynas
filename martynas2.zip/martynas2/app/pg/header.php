<!DOCTYPE html>
<html lang="">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Portfolio">
  <meta name="keywords" content="Martynas.Space, Photography, Analogue, Film Photography">
  <title>Martynas.Space</title>
  <link rel="icon" href="app/images/favicon.png" sizes="16x16" type="image/png">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@100;200;300;400;500;600;700&family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100&family=Source+Sans+Pro:wght@200;300;400;600;700&display=swap" rel="stylesheet">   
  <script src="https://kit.fontawesome.com/617bdfab8a.js" crossorigin="anonymous"></script>      
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />    
  <link rel="stylesheet" href="app/css/normalize.css">
  <link rel="stylesheet" href="app/css/style.css">  
</head>
<body>
        <div class="container">
            <!-- overlay menu -->
            <div id="myNav" class="overlay">
                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                <div class="overlay-content">
                       <a href="index.php">.home</a>
                        <a href="index.php?page=about">.about</a>
                        <a href="index.php?page=space">.space</a>
                        <a href="index.php?page=erosion">.erosion</a>
                        <a href="index.php?page=contact">.contact</a>
                  </div>
            </div>
            <!-- end menu -->
         
            <header class="site-header">   <!-- header -->
                    <div class="logo">
                        <a href="index.php"><h1>MARTYNAS.SPACE</h1></a>     
                    </div>
             </header>    <!-- end header -->  
             <header class="top-header">   <!-- header mobile -->
                 <div class="top-inside">
                    <div class="logo">
                        <a href="index.php"><h1>MARTYNAS.SPACE</h1></a>
                    </div> 
                    <div class="top-menu">
                            <i class="fas fa-bars top-fa" onclick="openNav()"></i>
                        </div>   
                </div>       
            </header>    