 <div class="scroll"> <!-- right sidebar -->
    <div class="scroll-right" id="arrow"> 
        <a class="previous"><i class="fas fa-angle-down"></i></a>
        <nav id="dot-nav">
        </nav>
        <a class="next"><i class="fas fa-angle-up" ></i></a> 
    </div>
</div> <!-- end right sidebar -->