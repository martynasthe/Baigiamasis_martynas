
<div class="content">   <!-- center -->                 
    <div class="centras cmob-top">   
        <section class="centras1 cmob">
               <div class="text">
                     <h2>.space</h2>
                     <p>Journeys within Analogue Photography
                    </p>
                </div>     
        </section>
        <section class="centras1 cflex sphl" > 
                <div class="photo pleft">
                     <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main12.jpg" alt="erosion"><img src="app/images/main12sm.jpg" alt="photo"></a>
                </div>
                <div class="photo pright">
                    <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main13.jpg" alt="erosion"><img src="app/images/main13sm.jpg" alt="erosion"></a>
                </div>
        </section>
        <section class="centras1 cflex sphl"> 
                <div class="photo pleft">
                     <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main21.jpg" alt="photo"><img src="app/images/main21sm.jpg" alt="photo"></a>
                </div>
                <div class="photo pright">
                     <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main22.jpg" alt="photo"><img src="app/images/main22sm.jpg" alt="photo"></a>
                </div>
        </section>
        <section class="centras1 cflex sph" > 
                <div class="photo pleft">
                     <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main11.jpg" alt="photo"><img src="app/images/main11sm.jpg" alt="photo"></a>
                </div>
                <div class="photo pcent">
                    <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main10.jpg" alt="photo"><img src="app/images/main10sm.jpg" alt="photo"></a>
                </div>
                <div class="photo pright">
                    <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main9.jpg" alt="photo"><img src="app/images/main9sm.jpg" alt="photo"></a>   
                </div>
        </section>
        <section class="centras1 cflex sph" > 
                <div class="photo pleft">
                     <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main6.jpg" alt="photo"><img src="app/images/main6sm.jpg" alt="photo"></a>
                </div>
                <div class="photo pcent">
                    <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main5.jpg" alt="photo"><img src="app/images/main5sm.jpg" alt="photo"></a>
                </div>
                <div class="photo pright">
                    <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main7.jpg" alt="photo"><img src="app/images/main7sm.jpg" alt="photo"></a>   
                </div>
        </section>
        <section class="centras1 cflex sph"> 
                <div class="photo pleft">
                     <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main1.jpg" alt="photo "><img src="app/images/main1sm.jpg" alt="photo"></a>
                </div>
                <div class="photo pcent">
                    <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main3.jpg"><img src="app/images/main3sm.jpg" alt="photo"></a>   
                </div>
                <div class="photo pright">
                    <a data-options='{"caption" : "Portrait"}' data-fancybox="gallery" href="app/images/main.jpg"><img src="app/images/mainsm.jpg" alt="photo"></a>
                </div>
        </section>
 
    </div>                     <!-- end center -->
</div> 