<div class="content">   <!-- center -->                 
    <div class="centras">   
        <section class="centras1">
            <img src="app/images/main.jpg" alt="the story">   
            <div class="link">
                <a href="index.php?page=space"><h3>.the story</h3></a>
            </div>      
        </section>
        <section class="centras2">
            <img src="app/images/main16.jpg" alt="erosion"> 
            <div class="link2 text">
                    <a href="index.php?page=erosion"><h2>.erosion</h2></a>
                    <p>is a collaborative multiseasonal collection created by A. Zukaite and J. Taroza.</p>
            </div>         
        </section>
        <section class="centras1 third third-mob">
                <div class="third-inside">
                    <div class="text">
                             <h2>“A true photograph need not be explained, nor can it be contained in words.” – Ansel Adams</h2>
                    </div>
                </div>     
        </section>
        <section class="centras1 third">
                <div class="third-inside"><img src="app/images/main17.jpg" alt="erosion">
                    <div class="inside-text">
                        <a href="index.php?page=erosion">     <h3>.erosion</h3></a>
                    </div>
                </div>     
        </section>
    </div>              <!-- end center -->
</div> 