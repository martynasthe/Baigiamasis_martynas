<?php 

     include('app/pg/header.php');
     include('app/pg/left.php');

     $path = 'app/pg/';
        $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '' ;
        $php  = '.php';
        $both = $path . $page . $php;
        $pages = array('main', 'about', 'space','erosion', 'contact');
        if (!empty($page)) {

        if(in_array($page,$pages)) {
        //$page .= '.php';
        include($both);
        }
        else {
        include('app/pg/404.php');
        }
        }
        else {
            include('app/pg/main.php');
        }

     include('app/pg/right.php');
     include('app/pg/footer.php');